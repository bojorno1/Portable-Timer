G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,10.0.7*
G04 #@! TF.CreationDate,2026-11-01T18:43:06-06:00*
G04 #@! TF.ProjectId,Button_Board,42757474-6f6e-45f4-926f-6172642e6b69,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Copper,L5,Inr*
G04 #@! TF.FilePolarity,Positive*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.7) date 2026-11-01 18:43:06*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 #@! TA.AperFunction,ComponentPad*
%ADD10R,1.700000X1.700000*%
G04 #@! TD*
G04 #@! TA.AperFunction,ComponentPad*
%ADD11C,1.700000*%
G04 #@! TD*
G04 #@! TA.AperFunction,ComponentPad*
%ADD12C,2.032000*%
G04 #@! TD*
G04 APERTURE END LIST*
D10*
G04 #@! TO.N,/Right*
G04 #@! TO.C,J11*
X70000000Y-45000000D03*
D11*
G04 #@! TO.N,/Center*
X70000000Y-47540000D03*
G04 #@! TO.N,/Left*
X70000000Y-50080000D03*
G04 #@! TO.N,GND*
X70000000Y-52620000D03*
G04 #@! TD*
D12*
G04 #@! TO.N,GND*
G04 #@! TO.C,SW4*
X130000000Y-55900000D03*
G04 #@! TO.N,/Right*
X125000000Y-53800000D03*
G04 #@! TD*
G04 #@! TO.N,GND*
G04 #@! TO.C,SW3*
X90000000Y-55900000D03*
G04 #@! TO.N,/Center*
X85000000Y-53800000D03*
G04 #@! TD*
G04 #@! TO.N,GND*
G04 #@! TO.C,SW2*
X50000000Y-55900000D03*
G04 #@! TO.N,/Left*
X45000000Y-53800000D03*
G04 #@! TD*
M02*
