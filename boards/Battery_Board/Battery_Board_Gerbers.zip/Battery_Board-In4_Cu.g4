G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,10.0.7*
G04 #@! TF.CreationDate,2026-11-01T18:41:37-06:00*
G04 #@! TF.ProjectId,Battery_Board,42617474-6572-4795-9f42-6f6172642e6b,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Copper,L5,Inr*
G04 #@! TF.FilePolarity,Positive*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.7) date 2026-11-01 18:41:37*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
G04 #@! TA.AperFunction,ComponentPad*
%ADD10RoundRect,0.249999X-1.250001X-1.250001X1.250001X-1.250001X1.250001X1.250001X-1.250001X1.250001X0*%
G04 #@! TD*
G04 #@! TA.AperFunction,ComponentPad*
%ADD11C,3.000000*%
G04 #@! TD*
G04 #@! TA.AperFunction,ComponentPad*
%ADD12R,1.700000X1.700000*%
G04 #@! TD*
G04 #@! TA.AperFunction,ComponentPad*
%ADD13C,1.700000*%
G04 #@! TD*
G04 #@! TA.AperFunction,ComponentPad*
%ADD14R,2.000000X2.000000*%
G04 #@! TD*
G04 #@! TA.AperFunction,ComponentPad*
%ADD15C,2.000000*%
G04 #@! TD*
G04 APERTURE END LIST*
D10*
G04 #@! TO.N,/BatteryPlus*
G04 #@! TO.C,BT1*
X100000000Y-100000000D03*
D11*
G04 #@! TO.N,GND*
X100000000Y-112700000D03*
G04 #@! TD*
D12*
G04 #@! TO.N,/Buzzer*
G04 #@! TO.C,J7*
X165220000Y-114460000D03*
D13*
G04 #@! TO.N,GND*
X165220000Y-117000000D03*
G04 #@! TD*
D14*
G04 #@! TO.N,/Buzzer*
G04 #@! TO.C,BZ1*
X165520000Y-100500000D03*
D15*
G04 #@! TO.N,GND*
X157920000Y-100500000D03*
G04 #@! TD*
D12*
G04 #@! TO.N,/BatteryPlus*
G04 #@! TO.C,J10*
X165220000Y-123730000D03*
D13*
G04 #@! TO.N,GND*
X165220000Y-126270000D03*
G04 #@! TD*
M02*
